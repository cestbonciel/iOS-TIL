//
//  PushNotificationManager.swift
//  CoffeePushWidget
//
//  Created by Nat Kim on 6/24/25.
//
import Foundation
import UserNotifications
import UIKit

@MainActor
final class PushNotificationManager: NSObject, ObservableObject {
    @Published var deviceToken: String?
    @Published var notificationPermissionStatus: UNAuthorizationStatus = .notDetermined
    @Published var lastNotification: [AnyHashable: Any]?
    
    override init() {
        super.init()
        UNUserNotificationCenter.current().delegate = self
        checkNotificationPermission()
    }
    
    // MARK: - Permission Management
    
    func requestNotificationPermission() async -> Bool {
        do {
            let granted = try await UNUserNotificationCenter.current().requestAuthorization(
                options: [.alert, .sound, .badge]
            )
            
            await MainActor.run {
                self.notificationPermissionStatus = granted ? .authorized : .denied
            }
            
            if granted {
                await registerForRemoteNotifications()
            }
            
            return granted
        } catch {
            print("❌ Failed to request notification permission: \(error)")
            return false
        }
    }
    
    private func checkNotificationPermission() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                self.notificationPermissionStatus = settings.authorizationStatus
            }
        }
    }
    
    // MARK: - Device Token Management
    
    @MainActor
    private func registerForRemoteNotifications() async {
        guard UIApplication.shared.isRegisteredForRemoteNotifications == false else {
            print("📱 Already registered for remote notifications")
            return
        }
        
        UIApplication.shared.registerForRemoteNotifications()
        print("📱 Registering for remote notifications...")
    }
    
    func setDeviceToken(_ tokenData: Data) {
        let token = tokenData.map { String(format: "%02.2hhx", $0) }.joined()
        
        Task { @MainActor in
            self.deviceToken = token
            print("🔑 Device Token: \(token)")
            
            // TODO: Supabase 연동 시 여기서 토큰을 서버에 전송
            await uploadDeviceTokenToSupabase(token)
        }
    }
    
    func setDeviceTokenError(_ error: Error) {
        print("❌ Failed to get device token: \(error)")
    }
    
    // MARK: - Supabase Integration (준비)
    
    private func uploadDeviceTokenToSupabase(_ token: String) async {
        // TODO: Supabase 프로젝트 설정 후 구현
        print("📤 Would upload device token to Supabase: \(token)")
        
        // 기존 방식과 호환 (임시)
        await sendTokenToServer(token)
    }
    
    // 기존 AppDelegate의 sendTokenToServer 로직을 여기로 이동
    private func sendTokenToServer(_ token: String) async {
        guard let url = URL(string: "http://localhost:3000/register-token") else {
            print("Invalid server URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let payload = ["token": token, "type": "general"]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
            
            let (_, _) = try await URLSession.shared.data(for: request)
            print("✅ Token sent to server successfully")
        } catch {
            print("❌ Token send error: \(error)")
        }
    }
    
    // 백그라운드 알림 처리
    func handleBackgroundNotification(_ userInfo: [AnyHashable: Any]) {
        Task { @MainActor in
            self.lastNotification = userInfo
            print("📱 Background notification processed by PushManager")
        }
    }
    
    // MARK: - Local Notification for Testing
    
    func scheduleTestNotification() async {
        let content = UNMutableNotificationContent()
        content.title = "☕ Coffee Time!"
        content.body = "Your perfect espresso is ready"
        content.sound = .default
        content.badge = 1
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(
            identifier: "test-coffee-notification",
            content: content,
            trigger: trigger
        )
        
        do {
            try await UNUserNotificationCenter.current().add(request)
            print("📲 Local test notification scheduled")
        } catch {
            print("❌ Failed to schedule notification: \(error)")
        }
    }
}

// MARK: - UNUserNotificationCenterDelegate

extension PushNotificationManager: UNUserNotificationCenterDelegate {
    
    // 앱이 포그라운드에 있을 때 알림 수신
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        print("📩 Received notification while app is active: \(notification.request.content.title)")
        
        // 포그라운드에서도 알림 표시
        completionHandler([.banner, .sound, .badge])
    }
    
    // 알림을 탭했을 때
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        let userInfo = response.notification.request.content.userInfo
        print("👆 User tapped notification: \(userInfo)")
        
        Task { @MainActor in
            self.lastNotification = userInfo
        }
        
        completionHandler()
    }
}

// MARK: - Helper Extensions

extension UNAuthorizationStatus {
    var description: String {
        switch self {
        case .notDetermined: return "Not Determined"
        case .denied: return "Denied"
        case .authorized: return "Authorized"
        case .provisional: return "Provisional"
        case .ephemeral: return "Ephemeral"
        @unknown default: return "Unknown"
        }
    }
} 
